﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;

using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace MidTermThingBreakOut
{
    class ScoreManager : DrawableGameComponent
    {

        

        SpriteFont font;
        public static int Lives;
        public static int Level;
        public static int Score;
        public static int Next = 1;

        public bool win = false;
        public bool lose = false;

        public string OutputResult = "";


        public void wining()
        {
            win = true;
        }

        public void loseing()
        {
            lose = true;
        }


        public void UpdateNext()
        {
            Next = Next + 1;
        }

        public int NextLevel()
        {
            return Next;
        }

        public int returnLives()
        {
            return Lives;
        }

        public int returnScore()
        {
            return Score;
        }

        public void ResetScore()
        {
            Score = 0;
        }

        public void SubtractOneLives()
        {
            Lives = Lives - 1;
        }

        Texture2D paddle;   //Texture for drawing lives left scoremanager is also the GUI/HUD

        SpriteBatch sb;
        Vector2 scoreLoc, livesLoc, levelLoc; //Locations to draw GUI elements


        public ScoreManager(Game game)
            : base(game)
        {
            SetupNewGame();
        }

        public override void Update(GameTime gameTime)
        {
            if (win == true)
            {
                OutputResult = "WIN";
            }
            else if (lose == true)
            {
                OutputResult = "DEFEATED";
            }

            base.Update(gameTime);
        }

        private static void SetupNewGame()  //Generally mixing static and non static methods is messy be careful
        {
            Lives = 3;
            Level = 1;
            Score = 0;
        }

        protected override void LoadContent()
        {
            sb = new SpriteBatch(this.Game.GraphicsDevice);
            font = this.Game.Content.Load<SpriteFont>("Arial");
            paddle = this.Game.Content.Load<Texture2D>("paddleSmall");
            livesLoc = new Vector2(10, 10); //Hard coded locations TODO fix for locations relative to window size
            levelLoc = new Vector2(300, 10);
            scoreLoc = new Vector2(400, 10);
            
            base.LoadContent();
        }

        public override void Draw(GameTime gameTime)
        {
            sb.Begin();
            for (int i = 0; i < Lives; i++)
            {
                sb.Draw(paddle, new Rectangle((65 * i) + 100, 15, paddle.Width / 2, paddle.Height / 2), Color.White);
            }
            sb.DrawString(font, "Lives: " + Lives, livesLoc, Color.White);
            sb.DrawString(font, "Score: " + Score, scoreLoc, Color.White);
            sb.DrawString(font, "Level: " + Level, levelLoc, Color.White);


            sb.DrawString(font, OutputResult, new Vector2((this.Game.GraphicsDevice.Viewport.Width / 2), (this.Game.GraphicsDevice.Viewport.Height / 2)), Color.White);
            
            sb.End();
            base.Draw(gameTime);
        }
    }
}