﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;

namespace MidTermThingBreakOut
{
    public class Level3 : BlockManager
    {

        public Level3(Game1 game, Ball b) : base(game, b)
        {
            ScoreManager.Lives = 3;
            ScoreManager.Level = 3;
        }

        protected override void LoadLevel()
        {
            ScoreManager.Level = 3;

            CreateBlockArrayByWidthAndHeight(24, 3, 1);
            //Load something differnt
        }
    }
}