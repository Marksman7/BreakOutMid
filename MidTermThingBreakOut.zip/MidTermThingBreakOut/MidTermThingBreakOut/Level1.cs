﻿using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MidTermThingBreakOut
{
    public class Level1 : BlockManager
    {
        ScoreManager Scorey;

        Level2 two;

        Level3 three;

        bool Ok = true;

        bool Oks = true;

        int Score = 0;

        public Level1(Game1 game, Ball b) : base(game, b)
        {
            two = new Level2(game, b);

            three = new Level3(game, b);

            Scorey = new ScoreManager(game);

            ScoreManager.Level = 1;
        }

        protected override void LoadLevel()
        {
            CreateBlockArrayByWidthAndHeight(24, 2, 1);
        }

        public override void Update(GameTime gameTime)
        {
            Score = 0 + Scorey.returnScore();

            UpdateNextOne();
        }

        private void UpdateNextOne()
        {
            if (Score >= 48 && Ok == true)
            {
                Game.Components.Add(two);

                Ok = false;
            }
            else if (Score >= 108 && Oks == true)
            {
                Game.Components.Add(three);

                Oks = false;
            }
        }
    }
}