﻿using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MidTermThingBreakOut
{
    public class Level2 : BlockManager
    {

        public Level2(Game1 game, Ball b) : base(game, b)
        {
            ScoreManager.Lives = 3;
            ScoreManager.Level = 2;
        }

        protected override void LoadLevel()
        {
            //ScoreManager.Level = 2;
            CreateBlockArrayByWidthAndHeight(20, 3, 1);
            //Load something differnt
        }


    }
}